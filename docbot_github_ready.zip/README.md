# DocBot
A personal Telegram bot for managing your documents.