import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, CallbackQueryHandler, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN")
AUTHORIZED_USER = os.getenv("AUTHORIZED_USER")
USER_PASSWORD = os.getenv("USER_PASSWORD")
ROOT_FOLDER_ID = os.getenv("ROOT_FOLDER_ID")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_user.id) != AUTHORIZED_USER:
        await update.message.reply_text("❌ Unauthorized access.")
        return
    await update.message.reply_text("📁 Welcome to your Personal Document Manager Bot!")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))

if __name__ == "__main__":
    print("🚀 Bot starting...")
    app.run_polling()
